package com.srevinsaju.newmun

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.widget.Toast

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK.or(Intent.FLAG_ACTIVITY_NEW_TASK)
        Handler().postDelayed(Runnable {
            kotlin.run {

                startActivity(intent)
                finish()
                Toast.makeText(this, "Welcome new user!", Toast.LENGTH_SHORT).show()
            }
        }, 4000)
    }
}
